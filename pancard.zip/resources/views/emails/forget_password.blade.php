<div>
    <p>
    Hello {{$name}},<br><br>

    Your One-Time Password (OTP) for logging in to your account at pancard is:

    {{$otp}}<br><br>

    Please enter this code on the login page to complete the login process.<br><br>

    If you did not request this OTP, please ignore this email.<br><br>

    Thank you,<br><br>
    PANCARD Team
    </p>
</div>
