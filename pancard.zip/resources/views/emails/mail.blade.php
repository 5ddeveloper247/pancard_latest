<!DOCTYPE html>
<html>

<head>
    <title>Email</title>
</head>

<body>

    {!! $body !!}
</body>

</html>
