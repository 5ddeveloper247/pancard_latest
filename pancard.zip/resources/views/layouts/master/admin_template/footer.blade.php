 <!-- footer -->
 <!-- <footer class="" style="text-center">
     All rights reserved.
     <div class=""> </div>
 </footer> -->
 

<script src="{{ asset('assets/plugins/jquery/jquery.min.js') }}"></script>
<script src="{{ asset('assets/plugins/popper/popper.min.js') }}" crossorigin="anonymous"></script>
<script src="{{ asset('assets/plugins/bootstrap/bootstrap.min.js') }}" crossorigin="anonymous"></script>
<script src="{{ asset('assets/plugins/toastr/toastr.min.js') }}"></script>
<script src="{{ asset('assets/plugins/moment/moment.min.js') }}"></script>
<script src="{{ asset('assets_admin/js/main.js') }}"></script>
<script src="{{ asset('assets_admin/customjs/common.js') }}"></script>

<script src="{{ asset('assets/plugins/daterangepicker/daterangepicker.min.js') }}"></script>


@stack('script')