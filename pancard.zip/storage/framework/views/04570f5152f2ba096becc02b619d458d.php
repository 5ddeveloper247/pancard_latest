 <!-- footer -->
 <!-- <footer class="" style="text-center">
     All rights reserved.
     <div class=""> </div>
 </footer> -->
 
<script src="<?php echo e(asset('assets_admin/plugins/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets_admin/plugins/popper/popper.min.js')); ?>" crossorigin="anonymous"></script>
<script src="<?php echo e(asset('assets_admin/plugins/bootstrap/bootstrap.min.js')); ?>" crossorigin="anonymous"></script>
<script src="<?php echo e(asset('assets_admin/plugins/toastr/toastr.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets_admin/plugins/moment/moment.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets_admin/js/main.js')); ?>"></script>
<script src="<?php echo e(asset('assets_admin/customjs/common.js')); ?>"></script>

<?php echo $__env->yieldPushContent('script'); ?><?php /**PATH C:\xampp\htdocs\pancard_laravel\resources\views/layouts/master/admin_template/footer.blade.php ENDPATH**/ ?>