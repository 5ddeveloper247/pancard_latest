<!DOCTYPE html>
<html>

<head>
    <title>Email</title>
</head>

<body>

    <?php echo $body; ?>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\pancard_laravel\resources\views/emails/mail.blade.php ENDPATH**/ ?>