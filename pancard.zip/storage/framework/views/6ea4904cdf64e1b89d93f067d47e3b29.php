 <!-- footer -->
 <!-- <footer class="" style="text-center">
     All rights reserved.
     <div class=""> </div>
 </footer> -->
 
<script src="<?php echo e(asset('assets_user/plugins/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets_user/plugins/popper/popper.min.js')); ?>" crossorigin="anonymous"></script>
<script src="<?php echo e(asset('assets_user/plugins/bootstrap/bootstrap.min.js')); ?>" crossorigin="anonymous"></script>
<script src="<?php echo e(asset('assets_user/plugins/toastr/toastr.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets_user/plugins/moment/moment.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets_user/js/main.js')); ?>"></script>
<script src="<?php echo e(asset('assets_user/customjs/common.js')); ?>"></script>

<?php echo $__env->yieldPushContent('script'); ?><?php /**PATH C:\xampp\htdocs\pancard_laravel\resources\views/layouts/master/user_template/footer.blade.php ENDPATH**/ ?>