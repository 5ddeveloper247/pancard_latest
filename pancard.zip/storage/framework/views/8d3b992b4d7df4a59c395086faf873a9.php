<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>PANCARD</title>
	<link rel="stylesheet" href="<?php echo e(asset('assets/plugins/bootstrap/bootstrap.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/toastr/toastr.min.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/fonts/fonts.google.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(asset('assets_user/css/style.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/daterangepicker/daterangepicker.css')); ?>" />
</head>

<body class="">
    <?php echo $__env->make('layouts.master.user_template.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
        <?php echo $__env->yieldContent('content'); ?>

	<?php echo $__env->make('layouts.master.user_template.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html>




<?php /**PATH C:\xampp\htdocs\pancard_latest\resources\views/layouts/master/user_template/master.blade.php ENDPATH**/ ?>