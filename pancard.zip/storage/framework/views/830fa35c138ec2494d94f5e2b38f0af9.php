 <!-- footer -->
 <!-- <footer class="" style="text-center">
     All rights reserved.
     <div class=""> </div>
 </footer> -->
 

<script src="<?php echo e(asset('assets/plugins/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/popper/popper.min.js')); ?>" crossorigin="anonymous"></script>
<script src="<?php echo e(asset('assets/plugins/bootstrap/bootstrap.min.js')); ?>" crossorigin="anonymous"></script>
<script src="<?php echo e(asset('assets/plugins/toastr/toastr.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/moment/moment.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets_admin/js/main.js')); ?>"></script>
<script src="<?php echo e(asset('assets_admin/customjs/common.js')); ?>"></script>

<script src="<?php echo e(asset('assets/plugins/daterangepicker/daterangepicker.min.js')); ?>"></script>


<?php echo $__env->yieldPushContent('script'); ?><?php /**PATH C:\xampp\htdocs\pancard_latest\resources\views/layouts/master/admin_template/footer.blade.php ENDPATH**/ ?>