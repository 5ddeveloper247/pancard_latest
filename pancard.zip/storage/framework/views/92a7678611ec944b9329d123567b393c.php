<div>
    <p>
    Hello <?php echo e($name); ?>,<br><br>

    Your One-Time Password (OTP) for logging in to your account at pancard is:

    <?php echo e($otp); ?><br><br>

    Please enter this code on the login page to complete the login process.<br><br>

    If you did not request this OTP, please ignore this email.<br><br>

    Thank you,<br><br>
    PANCARD Team
    </p>
</div>
<?php /**PATH C:\xampp\htdocs\pancard_laravel\resources\views/emails/forget_password.blade.php ENDPATH**/ ?>